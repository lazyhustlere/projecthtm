# ☁️ CloudBridge – AWS Scalable Cloud Infrastructure Project

CloudBridge is a production-ready cloud infrastructure project demonstrating modern AWS architecture, scalability, high availability, monitoring, security, networking, and content delivery.

The application is deployed on Amazon Linux (CentOS-compatible workflow) using Auto Scaling Groups, Application Load Balancer, CloudWatch monitoring, CloudFront CDN, Route 53 DNS, ACM SSL certificates, and a customized VPC architecture.

---

# 🌐 Live Architecture

```
                Internet
                    │
             CloudFront (CDN)
                    │
              ACM SSL Certificate
                    │
              Route 53 Hosted Zone
                    │
             Domain (Go54 Registrar)
                    │
        Application Load Balancer (ALB)
                    │
          Auto Scaling Group (ASG)
        ┌────────────┴────────────┐
        │                         │
    EC2 Instance             EC2 Instance
        │                         │
        └────────────┬────────────┘
                     │
          CloudWatch Logs & Metrics
                     │
             Customized Security Groups

VPC
├── Public Subnet
│      ├── ALB
│      └── Bastion Host
│
└── Private Subnet
       └── Application Servers
             ↑
        SSH Through Bastion Host
```

---

# 🚀 Project Overview

This project demonstrates how to build and deploy a highly available, scalable, and secure web application on AWS using cloud-native best practices.

The infrastructure includes:

- Highly Available Web Architecture
- Auto Scaling
- Load Balancing
- Cloud Monitoring
- Secure Networking
- SSL Encryption
- CDN Acceleration
- DNS Management
- Bastion Host Access
- Custom VPC Design

---

# ⚙️ Technologies Used

- HTML5
- CSS3
- JavaScript
- AWS EC2
- Amazon VPC
- Auto Scaling Group (ASG)
- Application Load Balancer (ALB)
- Amazon CloudWatch
- Route 53
- AWS Certificate Manager (ACM)
- Amazon CloudFront
- Go54 Domain Registrar
- Amazon Linux
- SSH
- Git

---

# 🏗 AWS Services Implemented

## ✅ Amazon EC2

- Hosted the CloudBridge website
- Amazon Linux server
- SSH secured access
- Web server configuration

---

## ✅ Custom VPC

Created a custom Virtual Private Cloud with:

- CIDR block
- Public Subnet
- Private Subnet
- Internet Gateway
- Route Tables
- Network ACLs
- Security Groups

---

## ✅ Public Subnet

Contains:

- Application Load Balancer
- Bastion Host

Provides internet access.

---

## ✅ Private Subnet

Contains:

- Web Application EC2 Instances

Instances are isolated from the internet.

---

## ✅ Bastion Host

Secure administrative access into the private subnet.

Connection flow:

```
Local Computer
       │
SSH
       │
Bastion Host
       │
SSH
       │
Private EC2 Instance
```

This ensures the application servers remain inaccessible directly from the internet.

---

## ✅ Security Groups

Custom Security Groups were configured for:

### ALB

Allowed

- HTTP (80)
- HTTPS (443)

---

### Bastion Host

Allowed

- SSH (22)
- Restricted to trusted IPs

---

### Private EC2

Allowed

- SSH only from Bastion Host
- HTTP only from ALB

This minimizes the attack surface and improves security.

---

# ⚖️ Auto Scaling Group (ASG)

Implemented an Auto Scaling Group to ensure:

- High Availability
- Automatic Recovery
- Horizontal Scaling
- Fault Tolerance

Features include:

- Launch Template
- Minimum Capacity
- Desired Capacity
- Maximum Capacity
- Health Checks
- Automatic Instance Replacement

---

# 🌍 Application Load Balancer (ALB)

Configured an Application Load Balancer to:

- Distribute traffic evenly
- Improve availability
- Remove unhealthy instances
- Support SSL termination

Benefits:

- No single point of failure
- Improved performance
- Automatic health checks

---

# 📊 Amazon CloudWatch

CloudWatch was configured to provide complete monitoring.

## Metrics

Collected:

- CPU Utilization
- Network In
- Network Out
- Disk Read
- Disk Write
- Memory Usage
- Instance Health

---

## CloudWatch Logs

Configured CloudWatch Agent to send:

- System Logs
- Web Server Logs
- Application Logs

This enables centralized log monitoring without logging into individual EC2 instances.

---

# 🌐 Domain Configuration

Purchased the custom domain from **Go54**.

Configured DNS using:

- Route 53 Hosted Zone
- Alias Records
- CloudFront Distribution

Result:

```
User

↓

Custom Domain

↓

Route53

↓

CloudFront

↓

Application Load Balancer

↓

EC2 Instances
```

---

# 🔐 SSL Certificate

Used **AWS Certificate Manager (ACM)**.

Benefits:

- HTTPS
- Encryption
- Secure communication
- Browser trust

---

# ☁️ Amazon CloudFront

Configured CloudFront CDN to:

- Cache static assets
- Reduce latency
- Improve global performance
- Provide HTTPS delivery

Benefits:

- Faster loading
- Better user experience
- Reduced origin server requests

---

# 📁 Project Structure

```
CloudBridge/

├── index.html
├── style.css
├── script.js
├── profile.jpeg
├── flyer1.jpeg
├── flyer2.jpeg
└── assets/
    └── favicon.png
```

---

# 🚀 Deployment Process

1. Launch EC2 instances.
2. Configure a custom VPC.
3. Create public and private subnets.
4. Configure Internet Gateway and route tables.
5. Deploy the application.
6. Create Launch Template.
7. Configure Auto Scaling Group.
8. Attach Application Load Balancer.
9. Install and configure CloudWatch Agent.
10. Create Route 53 Hosted Zone.
11. Request ACM SSL certificate.
12. Create CloudFront Distribution.
13. Point the Go54 domain to Route 53.
14. Test HTTPS access and automatic scaling.

---

# 🔒 Security Features

- Private application servers
- Bastion Host administration
- Restricted Security Groups
- HTTPS encryption
- Load Balancer health checks
- Auto Scaling self-healing
- Centralized logging with CloudWatch

---

# 📈 Scalability Features

- Automatic instance replacement
- Dynamic scaling
- Elastic Load Balancing
- Multi-instance deployment
- CloudFront edge caching
- Health monitoring

---

# 📸 Website Preview

The website includes:

- Responsive landing page
- Professional cloud engineering portfolio
- Services section
- About section
- Contact section
- Image gallery
- Interactive JavaScript components

---

# 🎯 Learning Objectives

This project demonstrates practical experience with:

- AWS Networking
- Cloud Infrastructure
- High Availability
- Scalability
- Monitoring
- Security
- DNS Management
- SSL Configuration
- CDN Implementation
- Infrastructure Best Practices

---

# 👨‍💻 Author

**Fayomi Adeseye Abimbola**

Cloud Computing Engineer | AWS Cloud Instructor | DevOps Enthusiast

- LinkedIn: https://www.linkedin.com/in/fay-cloud
- GitHub: https://github.com/fayomiadeseye64-spec

---

# ⭐ Key AWS Services Demonstrated

- Amazon EC2
- Amazon VPC
- Public & Private Subnets
- Bastion Host
- Security Groups
- Auto Scaling Group (ASG)
- Application Load Balancer (ALB)
- Amazon CloudWatch
- CloudWatch Logs
- Route 53
- AWS Certificate Manager (ACM)
- Amazon CloudFront
- Go54 Domain Integration
- SSH Administration

---

## License

This project is for educational, portfolio, and demonstration purposes.
